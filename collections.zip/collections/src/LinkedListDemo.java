package collections;
import java.util.LinkedList;
import java.util.List;


public class LinkedListDemo {

    public static void main(String[]args) {
        LinkedList<String> list=new LinkedList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");

        System.out.println("The elements in the original linked list are;"+list);
        list.addFirst("Z");
        System.out.println("Print the frist element in the array"+list);
        list.addLast("M");
        System.out.println("Print the last element in the array"+list);
        list.removeFirst();
        System.out.println("List after removing the first element in the array"+list);
        list.removeLast();
        System.out.println("List after removing the last element in the array"+list);

        String firstElement=list.getFirst();
        System.out.println("First element in the list " + firstElement);
        String lastElement= list.getLast();
        System.out.println("Last element in the list " +lastElement);
        boolean containsElement= list.contains("C");
        System.out.println(containsElement);
        boolean containsElement1= list.contains("F");
        System.out.println(containsElement1);
        int index=list.indexOf("D");
        System.out.println("The index of the element D is : "+index);



    }
}
